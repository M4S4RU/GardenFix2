﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using GardenLibrary;

namespace GardenLibraryTests
{
    [TestClass]
    public class LoginAndPAsswordCheckingClassTests
    {
        // ... предыдущие тесты ...

        [TestMethod]
        /// <summary>
        /// Тест, проверяющий логин длиной 4 символа.
        /// Ожидается, что метод вернет True.
        /// </summary>
        public void IsLoginValid_LoginLength4_ReturnsTrue()
        {
            string login = "abcd";
            bool result = LoginAndPAsswordCheckingClass.ValidationUtils.IsLoginValid(login);
            Assert.IsTrue(result);
        }

        [TestMethod]
        /// <summary>
        /// Тест, проверяющий логин длиной 20 символов.
        /// Ожидается, что метод вернет True.
        /// </summary>
        public void IsLoginValid_LoginLength20_ReturnsTrue()
        {
            string login = "abcdefghijklmnopqrst";
            bool result = LoginAndPAsswordCheckingClass.ValidationUtils.IsLoginValid(login);
            Assert.IsTrue(result);
        }

        [TestMethod]
        /// <summary>
        /// Тест, проверяющий логин содержащий только латинские буквы и цифры.
        /// Ожидается, что метод вернет True.
        /// </summary>
        public void IsLoginValid_LoginContainsOnlyLatinLettersAndDigits_ReturnsTrue()
        {
            string login = "AbCd1234";
            bool result = LoginAndPAsswordCheckingClass.ValidationUtils.IsLoginValid(login);
            Assert.IsTrue(result);
        }

        [TestMethod]
        /// <summary>
        /// Тест, проверяющий логин содержащий пробелы.
        /// Ожидается, что метод вернет False.
        /// </summary>
        public void IsLoginValid_LoginContainsSpaces_ReturnsFalse()
        {
            string login = "abcd efgh";
            bool result = LoginAndPAsswordCheckingClass.ValidationUtils.IsLoginValid(login);
            Assert.IsFalse(result);
        }

        [TestMethod]
        /// <summary>
        /// Тест, проверяющий пароль содержащий все необходимые символы.
        /// Ожидается, что метод вернет True.
        /// </summary>
        public void IsPasswordValid_PasswordContainsAllRequiredSymbols_ReturnsTrue()
        {
            string password = "Abc1234!";
            bool result = LoginAndPAsswordCheckingClass.ValidationUtils.IsPasswordValid(password);
            Assert.IsTrue(result);
        }

        // Остальные тесты...
    }
}
