﻿using GardenShopProject.Model;
using System.Data.Entity;
using System.Windows.Controls;

namespace GardenShopProject.View.Pages.AnonimPages
{
    public partial class TovarInfoPage : Page
    {
        private Tovar tovar;
        private Core db = new Core();

        public TovarInfoPage(Tovar tovar, Users user = null)
        {
            this.tovar = tovar;
            InitializeComponent();
            if(user == null)
            {
                AdminStackPanel.Visibility=System.Windows.Visibility.Collapsed;
            }
            // Заполнение полей информацией о товаре
            NameTextBlock.Text += tovar.Name;
            ArticleTextBlock.Text += tovar.Article;
            CostTextBlock.Text += tovar.Cost.ToString();
            CountTextBlock.Text += tovar.Count;
            DescriptionTextBlock.Text += tovar.Description;
        }

        private void DeleteButton_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            if (tovar != null)
            {
                  // Получаем товар из базы данных с помощью его идентификатора
                    var existingTovar = db.context.Tovar.Find(tovar.Id);

                    if (existingTovar != null)
                    {
                        // Удаляем найденный товар из базы данных
                        db.context.Tovar.Remove(existingTovar);
                        db.context.SaveChanges();
                    }
                

                // Перенаправление на предыдущую страницу
                NavigationService.GoBack();
            }
        }



        private void EditButton_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new RedactTovarPage(tovar));
        }
    }
}
