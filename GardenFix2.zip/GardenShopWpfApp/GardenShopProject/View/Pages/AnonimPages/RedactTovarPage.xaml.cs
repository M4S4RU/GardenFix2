﻿using GardenShopProject.Model;
using System;
using System.Data.Entity.Migrations;
using System.Windows;
using System.Windows.Controls;

namespace GardenShopProject.View.Pages.AnonimPages
{
    public partial class RedactTovarPage : Page
    {
        Core db= new Core();
        private Tovar _tovar;
        
        public RedactTovarPage(Tovar tovar)
        {
            InitializeComponent();
            _tovar = tovar;

            // Заполнение полей информацией о товаре
            NameTextBox.Text = tovar.Name;
            ArticleTextBox.Text = tovar.Article;
            CostTextBox.Text = tovar.Cost.ToString();
            CountTextBox.Text = tovar.Count;
            DescriptionTextBox.Text = tovar.Description;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // Получение отредактированных значений из TextBox и сохранение изменений в базе данных
            _tovar.Name = NameTextBox.Text;
            _tovar.Article = ArticleTextBox.Text;
            _tovar.Cost = Convert.ToInt32(CostTextBox.Text);
            _tovar.Count = CountTextBox.Text;
            _tovar.Description = DescriptionTextBox.Text;
            db.context.Tovar.AddOrUpdate(_tovar);
            // Сохранение изменений в базе данных
            db.context.SaveChanges();

            MessageBox.Show("Информация о товаре сохранена.");
            this.NavigationService.GoBack();
        }
    }
}
