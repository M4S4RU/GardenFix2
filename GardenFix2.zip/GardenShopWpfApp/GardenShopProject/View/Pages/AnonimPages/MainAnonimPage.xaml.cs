﻿using GardenShopProject.Model;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace GardenShopProject.View.Pages.AnonimPages
{
    public partial class MainAnonimPage : Page
    {
        Core db = new Core();
        public List<Tovar> TovarsList { get; set; }
        private Users users = new Users();
        public MainAnonimPage(Users user = null)
        {
            users = user;
            InitializeComponent();
            TovarsList = db.context.Tovar.ToList();
            DataContext = this;
            if(user == null)
            {
                AddButton.Visibility = Visibility.Collapsed;  
            }

            PopulateTovarStackPanel();
        }

        private void PopulateTovarStackPanel()
        {
            foreach (var tovar in TovarsList)
            {
                Button button = new Button();
                button.Content = tovar.Name;
                button.Margin = new Thickness(10);
                button.Click += (sender, e) => OpenDetailsPage(tovar); // Обработчик нажатия кнопки, передает экземпляр класса на другую страницу
                TovarStackPanel.Children.Add(button);
            }

            if (TovarsList.Count == 0)
            {
                TextBlock emptyTextBlock = new TextBlock();
                emptyTextBlock.Text = "Товары ещё не добавлены";
                emptyTextBlock.Margin = new Thickness(10);
                emptyTextBlock.HorizontalAlignment = HorizontalAlignment.Center;
                emptyTextBlock.VerticalAlignment = VerticalAlignment.Center;
                TovarStackPanel.Children.Add(emptyTextBlock);
            }
        }

        private void OpenDetailsPage(Tovar tovar)
        {
            
            // Создайте экземпляр страницы, на которую нужно перейти, и передайте ей экземпляр класса
            TovarInfoPage detailsPage = new TovarInfoPage(tovar,users);

            // Откройте новую страницу в главном окне приложения
            NavigationService?.Navigate(detailsPage);
        }

        private void AddButtonClick(object sender, RoutedEventArgs e)
        {
            AddTovarWindow add= new AddTovarWindow();
            add.Show(); 
        }
    }
}
