﻿using GardenShopProject.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GardenShopProject.View.Pages.AnonimPages
{
    /// <summary>
    /// Логика взаимодействия для AddTovarWindow.xaml
    /// </summary>
    public partial class AddTovarWindow : Window
    {
        Core db = new Core();
        public AddTovarWindow()
        {
            InitializeComponent();
        }

       

        private void SaveButtonClick(object sender, RoutedEventArgs e)
        {
            Tovar tovar = new Tovar()
            {
                Article=ArticleTextBox.Text,
                Cost=Convert.ToInt32(CostTextBox.Text),
                Count=CountTextBox.Text,
                Description=DescTextBox.Text,
                Name=NameTextBox.Text,
                
            };
            db.context.Tovar.Add(tovar);
            db.context.SaveChanges();
            MessageBox.Show("Товар успешно добавлен");
            Close();
        }
    }
}
