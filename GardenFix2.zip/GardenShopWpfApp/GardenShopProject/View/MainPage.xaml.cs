﻿using GardenLibrary;
using GardenShopProject.Model;
using GardenShopProject.View.Pages.AnonimPages;
using GardenShopProject.View.Pages.ManagersPages;
using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GardenShopProject.View
{
    /// <summary>
    /// Логика взаимодействия для MainPage.xaml
    /// </summary>
    public partial class MainPage : Page
    {
       Core db = new Core();
        public MainPage()
        {
            InitializeComponent();
            
        }
    

        private void AnonimHyperlink_Click(object sender, RoutedEventArgs e)
        {
            // Создаем экземпляр целевой страницы
            MainAnonimPage targetPage = new MainAnonimPage();

            // Выполняем навигацию на целевую страницу
            this.NavigationService.Navigate(targetPage);
        }

        private void SignInButton_Click(object sender, RoutedEventArgs e)
        {
            if(LoginAndPAsswordCheckingClass.ValidationUtils.IsLoginValid(LoginTextBox.Text)&& LoginAndPAsswordCheckingClass.ValidationUtils.IsPasswordValid(PasswordPasswordBox.Password))
            {
                if (db.context.Users.Where(x => x.Login == LoginTextBox.Text).FirstOrDefault() != null)
                {
                    if(db.context.Users.Where(x => x.Password == PasswordPasswordBox.Password).FirstOrDefault() != null)
                    {
                        Users user= db.context.Users.FirstOrDefault(x=>x.Login == LoginTextBox.Text);
                        this.NavigationService.Navigate(new MainAnonimPage(user));
                    }
                    else
                    {
                        MessageBox.Show("Неправильный пароль");
                    }
                }
                else
                {
                    MessageBox.Show("Такого пользователя не существует");
                }
            }
            else
            {
                MessageBox.Show("Логин или пароль не прошли проверку");
            }
        }
        
    }
}
