﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GardenShopProject.Model
{
    public class Core
    {
       public GardenEntities context = new GardenEntities();
    }
}
