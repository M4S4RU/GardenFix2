﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace GardenLibrary
{
    public class LoginAndPAsswordCheckingClass
    {
        public static class ValidationUtils
        {
            /// <summary>
            /// Проверяет логин на соответствие заданным условиям.
            /// Логин должен состоять только из латинских букв и цифр, быть длиной от 4 до 20 символов.
            /// </summary>
            /// <param name="login">Логин для проверки.</param>
            /// <returns>True, если логин соответствует условиям, иначе False.</returns>
            public static bool IsLoginValid(string login)
            {
                if (string.IsNullOrEmpty(login))
                    return false;

                if (login.Length < 4 || login.Length > 20)
                    return false;

                if (!Regex.IsMatch(login, "^[a-zA-Z0-9]+$"))
                    return false;

                // Другие проверки логина...

                return true;
            }

            /// <summary>
            /// Проверяет пароль на соответствие заданным условиям.
            /// Пароль должен содержать как минимум 8 символов, включать минимум одну заглавную и одну строчную букву,
            /// одну цифру и один специальный символ.
            /// </summary>
            /// <param name="password">Пароль для проверки.</param>
            /// <returns>True, если пароль соответствует условиям, иначе False.</returns>
            public static bool IsPasswordValid(string password)
            {
                if (string.IsNullOrEmpty(password))
                    return false;

                if (password.Length < 8)
                    return false;

                if (!Regex.IsMatch(password, @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*\W).+$"))
                    return false;

                // Другие проверки пароля...

                return true;
            }
        }


    }
}
